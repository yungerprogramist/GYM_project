import { ProgramDayApi } from '../api/programs-api';

export const PROGRAM_DAYS_MOCK: ProgramDayApi[] = [
  {
    id: 1,
    name: 'День 1 - Сила верха',
    day_number: 1,
    exercises: [
      { id: 101, exercise: 1, exercise_name: 'Жим лежа - штанга', exercise_order: 1 },
      { id: 102, exercise: 2, exercise_name: 'Жим лежа (наклон) - гантели', exercise_order: 2 },
      { id: 103, exercise: 3, exercise_name: 'Тяга в наклоне - штанга', exercise_order: 3 },
      { id: 104, exercise: 4, exercise_name: 'Вертикальная тяга - верхний блок', exercise_order: 4 },
      { id: 105, exercise: 5, exercise_name: 'Жим над головой - штанга', exercise_order: 5 },
      { id: 106, exercise: 6, exercise_name: 'Сгибание рук - штанга', exercise_order: 6 },
      { id: 107, exercise: 7, exercise_name: 'Разгибание рук лежа - штанга', exercise_order: 7 },
    ],
  },
  {
    id: 2,
    name: 'День 2 - Сила низа',
    day_number: 2,
    exercises: [
      { id: 201, exercise: 8, exercise_name: 'Приседания со штангой', exercise_order: 1 },
      { id: 202, exercise: 9, exercise_name: 'Выпады с гантелями', exercise_order: 2 },
      { id: 203, exercise: 10, exercise_name: 'Подъём на носки', exercise_order: 3 },
      { id: 204, exercise: 11, exercise_name: 'Скручивания', exercise_order: 4 },
      { id: 205, exercise: 12, exercise_name: 'Планка', exercise_order: 5 },
    ],
  },
  {
    id: 3,
    name: 'День 4 - Гипертрофия верха',
    day_number: 4,
    exercises: [
      { id: 301, exercise: 13, exercise_name: 'Жим гантелей лёжа', exercise_order: 1 },
      { id: 302, exercise: 14, exercise_name: 'Разведение гантелей', exercise_order: 2 },
      { id: 303, exercise: 15, exercise_name: 'Тяга горизонтального блока', exercise_order: 3 },
      { id: 304, exercise: 16, exercise_name: 'Шраги со штангой', exercise_order: 4 },
      { id: 305, exercise: 17, exercise_name: 'Махи гантелями в стороны', exercise_order: 5 },
      { id: 306, exercise: 18, exercise_name: 'Сгибание рук на скамье Скотта', exercise_order: 6 },
    ],
  },
  {
    id: 4,
    name: 'День 5 - Гипертрофия низа',
    day_number: 5,
    exercises: [
      { id: 401, exercise: 19, exercise_name: 'Румынская тяга', exercise_order: 1 },
      { id: 402, exercise: 20, exercise_name: 'Сгибание ног в тренажёре', exercise_order: 2 },
      { id: 403, exercise: 21, exercise_name: 'Разгибание ног', exercise_order: 3 },
      { id: 404, exercise: 22, exercise_name: 'Подъём ног в висе', exercise_order: 4 },
      { id: 405, exercise: 23, exercise_name: 'Боковая планка', exercise_order: 5 },
    ],
  },
];