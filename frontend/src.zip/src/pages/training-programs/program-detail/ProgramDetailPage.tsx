import React from 'react';
import {
  Box,
  Paper,
  Typography,
  IconButton,
  List,
  Snackbar,
  Alert,
  CircularProgress,
  Divider,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useProgramDetail } from '../hooks/useProgramDetail';
import { DayTabs } from './DayTabs';
import { ExerciseItem } from './ExerciseItem';

interface Props {
  programId: string;
  programName: string;
  onBack: () => void;
}

export const ProgramDetailPage: React.FC<Props> = ({ programId, programName, onBack }) => {
  const {
    days,
    activeDayIndex,
    completedExercises,
    loading,
    error,
    snackbar,
    setActiveDayIndex,
    toggleExercise,
    closeSnackbar,
  } = useProgramDetail(programId);

  const currentDay = days[activeDayIndex];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
      <Paper
        elevation={2}
        sx={{
          borderRadius: 4,
          overflow: 'hidden',
          bgcolor: 'rgba(255,255,255,0.8)',
        }}
      >
        {/* Заголовок со стрелкой назад */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            p: 3,
            pb: 2,
          }}
        >
          <IconButton
            onClick={onBack}
            sx={{
              mr: 2,
              color: 'text.secondary',
              '&:hover': { color: 'text.primary' },
            }}
            aria-label="Вернуться к списку программ"
          >
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h5" fontWeight={300} color="text.secondary">
            {programName}
          </Typography>
        </Box>

        {/* Табы дней */}
        <Box sx={{ px: 3 }}>
          <DayTabs
            days={days}
            activeIndex={activeDayIndex}
            onChange={setActiveDayIndex}
          />
        </Box>

        <Divider sx={{ mx: 3 }} />

        {/* Контент активного дня */}
        <Box sx={{ p: 3 }}>
          {currentDay && (
            <>
              <Typography
                variant="h6"
                sx={{
                  mb: 2,
                  color: 'text.disabled',
                  fontWeight: 300,
                }}
              >
                {currentDay.name}
              </Typography>

              <List sx={{ py: 0 }} aria-label="Список упражнений">
                {currentDay.exercises.map((ex) => (
                  <ExerciseItem
                    key={ex.id}
                    id={ex.id}
                    name={ex.exercise_name}
                    order={ex.exercise_order}
                    isCompleted={completedExercises.has(ex.id)}
                    onToggle={toggleExercise}
                  />
                ))}
              </List>
            </>
          )}
        </Box>
      </Paper>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={2500}
        onClose={closeSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert
          onClose={closeSnackbar}
          severity="success"
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};