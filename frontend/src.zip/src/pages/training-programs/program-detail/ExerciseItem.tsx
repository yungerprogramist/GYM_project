import React from 'react';
import {
  ListItem,
  ListItemText,
  IconButton,
  Box,
  Typography,
} from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';

interface Props {
  id: number;
  name: string;
  order: number;
  isCompleted: boolean;
  onToggle: (id: number, name: string) => void;
}

export const ExerciseItem: React.FC<Props> = React.memo(
  ({ id, name, order, isCompleted, onToggle }) => (
    <ListItem
      sx={{
        py: 1.5,
        px: 2,
        mb: 1,
        borderRadius: 3,
        bgcolor: isCompleted ? 'rgba(165, 214, 167, 0.15)' : 'rgba(0,0,0,0.02)',
        border: '1px solid',
        borderColor: isCompleted ? 'rgba(165, 214, 167, 0.3)' : 'transparent',
        transition: 'all 0.2s ease',
        '&:hover': {
          bgcolor: isCompleted ? 'rgba(165, 214, 167, 0.2)' : 'rgba(0,0,0,0.04)',
        },
      }}
      secondaryAction={
        <IconButton
          edge="end"
          onClick={() => onToggle(id, name)}
          color={isCompleted ? 'success' : 'default'}
          sx={{
            transition: 'all 0.2s',
            '&:hover': {
              bgcolor: isCompleted ? 'rgba(76, 175, 80, 0.1)' : 'rgba(0,0,0,0.04)',
            },
          }}
          aria-label={isCompleted ? `Убрать ${name}` : `Добавить ${name}`}
        >
          {isCompleted ? <CheckIcon /> : <CheckBoxOutlineBlankIcon />}
        </IconButton>
      }
    >
      <Box
        sx={{
          width: 36,
          height: 36,
          borderRadius: 2,
          bgcolor: isCompleted ? '#a5d6a7' : '#e0e0e0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          mr: 2,
          flexShrink: 0,
          transition: 'background-color 0.2s',
        }}
      >
        <Typography variant="caption" fontWeight={700} color="rgba(0,0,0,0.5)">
          {order}
        </Typography>
      </Box>

      <ListItemText
        primary={
          <Typography
            fontWeight={500}
            sx={{
              textDecoration: isCompleted ? 'line-through' : 'none',
              color: isCompleted ? 'text.secondary' : 'text.primary',
              transition: 'all 0.2s',
            }}
          >
            {name}
          </Typography>
        }
      />
    </ListItem>
  )
);

ExerciseItem.displayName = 'ExerciseItem';