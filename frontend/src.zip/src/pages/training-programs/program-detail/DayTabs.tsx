import React from 'react';
import { Tabs, Tab, Box, Typography } from '@mui/material';
import { ProgramDayApi } from '../api/programs-api';

interface Props {
  days: ProgramDayApi[];
  activeIndex: number;
  onChange: (index: number) => void;
}

export const DayTabs: React.FC<Props> = React.memo(({ days, activeIndex, onChange }) => (
  <Tabs
    value={activeIndex}
    onChange={(_, v) => onChange(v)}
    variant="scrollable"
    scrollButtons="auto"
    allowScrollButtonsMobile
    textColor="primary"
    indicatorColor="transparent"
    sx={{
      mb: 2,
      '& .MuiTabs-flexContainer': { gap: 1, px: 1 },
    }}
  >
    {days.map((day, index) => (
      <Tab
        key={day.id}
        label={
          <Box sx={{ textAlign: 'left', py: 0.5 }}>
            <Typography
              variant="body2"
              fontWeight={600}
              sx={{
                mb: 0.5,
                color: index === activeIndex ? 'text.primary' : 'text.secondary',
              }}
            >
              {day.name}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {day.exercises.length} упражнений
            </Typography>
          </Box>
        }
        value={index}
        sx={{
          textTransform: 'none',
          minWidth: 200,
          borderRadius: 3,
          alignItems: 'flex-start',
          bgcolor: index === activeIndex ? 'rgba(0,0,0,0.04)' : 'transparent',
          border: '1px solid',
          borderColor: index === activeIndex ? 'rgba(0,0,0,0.1)' : 'transparent',
          transition: 'all 0.2s',
          '&:hover': {
            bgcolor: 'rgba(0,0,0,0.04)',
          },
        }}
      />
    ))}
  </Tabs>
));

DayTabs.displayName = 'DayTabs';