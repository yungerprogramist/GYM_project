import { useState, useEffect, useCallback } from 'react';
import { programsApi, ProgramDayApi } from '../api/programs-api';
import { PROGRAM_DAYS_MOCK } from '../mocks/program-days.mock';

const USE_MOCK = true; // Поставьте false когда бэкенд будет готов

interface UseProgramDetailReturn {
  days: ProgramDayApi[];
  activeDayIndex: number;
  completedExercises: Set<number>;
  loading: boolean;
  error: string | null;
  snackbar: { open: boolean; message: string };
  setActiveDayIndex: (index: number) => void;
  toggleExercise: (exerciseId: number, exerciseName: string) => void;
  closeSnackbar: () => void;
}

export const useProgramDetail = (programId: string): UseProgramDetailReturn => {
  const [days, setDays] = useState<ProgramDayApi[]>([]);
  const [activeDayIndex, setActiveDayIndex] = useState(0);
  const [completedExercises, setCompletedExercises] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '' });

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        if (USE_MOCK) {
          // Мок-режим: используем локальные данные
          setDays(PROGRAM_DAYS_MOCK);
        } else {
          // API-режим: запрос к бэкенду
          const data = await programsApi.getById(programId);
          setDays(data.days);
        }
      } catch (err) {
        setError('Ошибка загрузки программы');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [programId]);

  const toggleExercise = useCallback((exerciseId: number, exerciseName: string) => {
    setCompletedExercises((prev) => {
      const next = new Set(prev);
      if (next.has(exerciseId)) {
        next.delete(exerciseId);
      } else {
        next.add(exerciseId);
        setSnackbar({ open: true, message: `Упражнение «${exerciseName}» добавлено` });
      }
      return next;
    });
  }, []);

  const closeSnackbar = useCallback(() => {
    setSnackbar((prev) => ({ ...prev, open: false }));
  }, []);

  return {
    days,
    activeDayIndex,
    completedExercises,
    loading,
    error,
    snackbar,
    setActiveDayIndex,
    toggleExercise,
    closeSnackbar,
  };
};