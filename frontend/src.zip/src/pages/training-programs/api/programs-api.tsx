import { authFetch } from '../../login-page/auth';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

export interface ProgramDayApi {
  id: number;
  name: string;
  day_number: number;
  exercises: {
    id: number;
    exercise: number;
    exercise_name: string;
    exercise_order: number;
  }[];
}

export interface ProgramDetailApi {
  id: number;
  name: string;
  difficulty: string;
  description: string;
  days: ProgramDayApi[];
}

export const programsApi = {
  getList: () => authFetch(`${API_URL}/programs/`),

  getById: (id: string) =>
    authFetch<ProgramDetailApi>(`${API_URL}/programs/${id}/`),

  getDayExercises: (programId: string, dayId: number) =>
    authFetch<ProgramDayApi>(`${API_URL}/programs/${programId}/days/${dayId}/`),

  importDay: (programId: string, dayId: number) =>
    authFetch(`${API_URL}/programs/${programId}/days/${dayId}/import/`, {
      method: 'POST',
    }),
};